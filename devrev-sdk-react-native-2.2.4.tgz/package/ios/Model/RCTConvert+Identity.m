#import "RCTConvert+Identity.h"
#import <DevRevSDK/DevRevSDK.h>

@implementation RCTConvert (Identity)

+ (Identity *)identity:(id)json
{
	json = [self NSDictionary:json];
	return [[Identity alloc] initWithUserID:[self NSString:json[@"userRef"]]
							 organizationID:[self NSString:json[@"organizationRef"]]
								  accountID:[self NSString:json[@"accountRef"]]
								 userTraits:[self userTraits:json[@"userTraits"]]
						 organizationTraits:[self organizationTraits:json[@"organizationTraits"]]
							  accountTraits:[self accountTraits:json[@"accountTraits"]]];
}

+ (UserTraits *)userTraits:(id)json
{
	json = [self NSDictionary:json];
	return [[UserTraits alloc] initWithDisplayName:[self NSString:json[@"displayName"]]
											 email:[self NSString:json[@"email"]]
										  fullName:[self NSString:json[@"fullName"]]
								   userDescription:[self NSString:json[@"description"]]
									  phoneNumbers:[self NSStringArray:json[@"phoneNumbers"]]
									  customFields:[self NSDictionary:json[@"customFields"]]];
}

+ (OrganizationTraits *)organizationTraits:(id)json
{
	json = [self NSDictionary:json];
	return [[OrganizationTraits alloc] initWithDisplayName:[self NSString:json[@"displayName"]]
													domain:[self NSString:json[@"domain"]]
								   organizationDescription:[self NSString:json[@"description"]]
											  phoneNumbers:[self NSStringArray:json[@"phoneNumbers"]]
													  tier:[self NSString:json[@"tier"]]
											  customFields:[self NSDictionary:json[@"customFields"]]];
}

+ (AccountTraits *)accountTraits:(id)json
{
	json = [self NSDictionary:json];
	return [[AccountTraits alloc] initWithDisplayName:[self NSString:json[@"displayName"]]
											  domains:[self NSStringArray:json[@"domains"]]
								   accountDescription:[self NSString:json[@"description"]]
										 phoneNumbers:[self NSStringArray:json[@"phoneNumbers"]]
											 websites:[self NSStringArray:json[@"websites"]]
												 tier:[self NSString:json[@"tier"]]
										 customFields:[self NSDictionary:json[@"customFields"]]];
}

@end
