#import "RCTConvert.h"
#import <DevRevSDK/DevRevSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface RCTConvert (Identity)

+ (Identity *)identity:(id)json;
+ (UserTraits *)userTraits:(id)json;
+ (OrganizationTraits *)organizationTraits:(id)json;
+ (AccountTraits *)accountTraits:(id)json;

@end

NS_ASSUME_NONNULL_END
