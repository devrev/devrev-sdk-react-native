import type { TurboModule } from 'react-native';
import { TurboModuleRegistry } from 'react-native';

export interface Spec extends TurboModule {
  /*
   * Configuration
   */

  configure(appId: string, version: string): void;

  /*
   * Identification
   */

  identifyUnverifiedUser(userId: string, organizationId?: string): void;
  identifyVerifiedUser(userId: string, sessionToken: string): void;
  identifyAnonymousUser(userId: string): void;
  updateUser(identity: Object): void;
  logout(deviceId: string): void;

  /*
   * Support
   */

  showSupport(): void;
  createSupportConversation(): void;

  /*
   * Analytics
   */

  trackEvent(name: string, properties?: Object): void;

  /*
   * Session recording
   */

  startRecording(): void;
  stopRecording(): void;
  pauseRecording(): void;
  resumeRecording(): void;
  pauseUserInteractionTracking(): void;
  resumeUserInteractionTracking(): void;
  processAllOnDemandSessions(): void;

  /*
   * Session properties
   */

  addSessionProperties(properties: Object): void;
  clearSessionProperties(): void;

  /*
   * Sensitive field masking
   */

  markSensitiveViews(views: ReadonlyArray<Object>): void;
  unmarkSensitiveViews(views: ReadonlyArray<Object>): void;

  /*
   * Timer control
   */

  startTimer(name: string, properties?: Object): void;
  endTimer(name: string, properties?: Object): void;

  /*
   * Monitoring
   */

  resumeAllMonitoring(): void;
  stopAllMonitoring(): void;

  /*
   * Screen tracking
   */

  trackScreenName(name: string): void;

  /*
   * Push notifications
   */

  registerDeviceToken(deviceToken: string, deviceId: string): void;
  unregisterDevice(deviceId: string): void;
  processPushNotification(payload: string): void;

  /*
   * In-app link handling
   */

  setInAppLinkHandler(): void;
  setShouldDismissModalsOnOpenLink(value: boolean): void;

  /*
   * Dynamic theme configuration
   */

  setPrefersSystemTheme(value: boolean): void;

  /*
   * Screen transition management
   */

  setInScreenTransitioning(value: boolean): void;

  /*
   * Constants
   */

  getConstants(): {
    EVENT_IN_APP_LINK: string;
  };

  /*
   * Event listener management
   */

  addListener(eventName: string): void;
  removeListeners(count: number): void;

  /*
   * Error capture
   */

  captureError(error: string, tag: string, stackTrace?: string): void;
}

export default TurboModuleRegistry.getEnforcing<Spec>('DevRevSDK');
