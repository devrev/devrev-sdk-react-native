package ai.devrev.sdk.bridge.reactnative

import com.facebook.react.bridge.ReactApplicationContext

object DevRevSDKModuleFactory {
    fun create(reactContext: ReactApplicationContext): IDevRevSDKModule = DevRevSDKModuleImpl(reactContext)
}
