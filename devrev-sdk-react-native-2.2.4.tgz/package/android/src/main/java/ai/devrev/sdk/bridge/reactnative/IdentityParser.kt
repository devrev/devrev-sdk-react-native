package ai.devrev.sdk.bridge.reactnative

import ai.devrev.sdk.model.Identity
import ai.devrev.sdk.model.UserInfo
import ai.devrev.sdk.model.OrganizationInfo
import ai.devrev.sdk.model.AccountInfo

import com.facebook.react.bridge.ReadableMap
import com.facebook.react.bridge.ReadableArray

object IdentityParser {
  fun parseIdentity(map: ReadableMap): Identity {
    return Identity(
      userId = map.getString("userRef") ?: "",
      organizationId = map.getString("organizationRef"),
      accountId = map.getString("accountRef"),
      userInfo = map.getMap("userTraits")?.let { parseUserTraits(it) },
      organizationInfo = map.getMap("organizationTraits")?.let { parseOrganizationTraits(it) },
      accountInfo = map.getMap("accountTraits")?.let { parseAccountTraits(it) }
    )
  }

  private fun parseUserTraits(map: ReadableMap) = UserInfo(
    displayName = map.getString("displayName"),
    email = map.getString("email"),
    fullName = map.getString("fullName"),
    description = map.getString("description"),
    phoneNumbers = map.getArray("phoneNumbers")?.toStringList(),
    customFields = map.getMap("customFields")?.toAnyMap()
  )

  private fun parseOrganizationTraits(map: ReadableMap) = OrganizationInfo(
    displayName = map.getString("displayName"),
    domain = map.getString("domain"),
    description = map.getString("description"),
    phoneNumbers = map.getArray("phoneNumbers")?.toStringList(),
    tier = map.getString("tier"),
    customFields = map.getMap("customFields")?.toAnyMap()
  )

  private fun parseAccountTraits(map: ReadableMap) = AccountInfo(
    displayName = map.getString("displayName"),
    domains = map.getArray("domains")?.toStringList(),
    description = map.getString("description"),
    phoneNumbers = map.getArray("phoneNumbers")?.toStringList(),
    websites = map.getArray("websites")?.toStringList(),
    tier = map.getString("tier"),
    customFields = map.getMap("customFields")?.toAnyMap()
  )

  private fun ReadableArray.toStringList(): List<String> {
    return (0 until size()).mapNotNull { getString(it) }
  }

  private fun ReadableMap.toAnyMap(): Map<String, Any>? {
    val result = mutableMapOf<String, Any>()
    this.entryIterator.forEach { entry ->
        when (val value = entry.value) {
            is String, is Number, is Boolean -> result[entry.key] = value
            is ReadableMap -> {
                value.toAnyMap()?.let { nestedMap ->
                    result[entry.key] = nestedMap
                }
            }
        }
    }
    return result.takeIf { it.isNotEmpty() }
}
}
