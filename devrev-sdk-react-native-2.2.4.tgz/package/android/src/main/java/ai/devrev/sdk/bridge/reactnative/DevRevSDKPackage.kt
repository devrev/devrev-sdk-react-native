package ai.devrev.sdk.bridge.reactnative

import com.facebook.react.TurboReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.module.model.ReactModuleInfo
import com.facebook.react.module.model.ReactModuleInfoProvider
import com.facebook.react.uimanager.ViewManager

class DevRevSDKPackage : TurboReactPackage() {
    override fun getModule(name: String, reactContext: ReactApplicationContext): NativeModule? {
        return when (name) {
            DevRevSDKModule.NAME -> DevRevSDKModule(reactContext)
            else -> null
        }
    }

    override fun getReactModuleInfoProvider(): ReactModuleInfoProvider {
        val isTurboModule: Boolean = BuildConfig.IS_NEW_ARCHITECTURE_ENABLED
        return ReactModuleInfoProvider {
            mapOf(
                DevRevSDKModule.NAME to ReactModuleInfo(
                    DevRevSDKModule.NAME,
                    DevRevSDKModule.NAME,
                    false, // canOverrideExistingModule
                    false,  // needsEagerInit
                    true,  // hasConstants
                    false, // isCxxModule
                    isTurboModule   // isTurboModule
                )
            )
        }
    }

    override fun createNativeModules(reactContext: ReactApplicationContext): List<NativeModule> {
      return listOf(DevRevSDKModule(reactContext))
    }

    override fun createViewManagers(reactContext: ReactApplicationContext): List<ViewManager<*, *>> {
      return emptyList()
    }

}
