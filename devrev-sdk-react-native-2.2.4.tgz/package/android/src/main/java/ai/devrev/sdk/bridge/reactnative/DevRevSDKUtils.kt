package ai.devrev.sdk.bridge.reactnative

import com.facebook.react.bridge.ReactApplicationContext
import android.view.View
import com.facebook.react.uimanager.UIManagerHelper
import com.facebook.react.bridge.ReadableArray
import android.util.Log

fun convertReactTagsToViews(context: ReactApplicationContext, viewTags: ReadableArray): List<View> {
    val views = mutableListOf<View>()
    for (i in 0 until viewTags.size()) {
        val viewTag = viewTags.getInt(i)
        val uiManager = UIManagerHelper.getUIManagerForReactTag(context, viewTag)
        try {
            val view = uiManager?.resolveView(viewTag)
            view?.let { views.add(it) }
        } catch (e: Exception) {
            Log.e("DevRevSDK", "Could not resolve view with tag: $viewTag", e)
        }
    }
    return views
}
