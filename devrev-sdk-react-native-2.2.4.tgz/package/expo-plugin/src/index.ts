import { withDevRev } from './withDevRev';

export { withDevRev };

export default withDevRev;
