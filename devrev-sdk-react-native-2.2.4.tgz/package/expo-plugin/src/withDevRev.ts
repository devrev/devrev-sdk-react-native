import { type ConfigPlugin, withAppBuildGradle } from '@expo/config-plugins';

const ANDROID_SDK_VERSION = '2.2.10';
const ANDROID_SNAPSHOT_REPO_URL =
  'https://central.sonatype.com/repository/maven-snapshots/';

export const withDevRev: ConfigPlugin = (config) => {
  // Modify the Android configuration.
  return withDevRevAndroid(config);
};

const withDevRevAndroid: ConfigPlugin = (config) => {
  // Add the maven repository.
  config = withAppBuildGradle(config, (newConfig) => {
    if (newConfig.modResults.contents) {
      newConfig.modResults.contents = newConfig.modResults.contents.replace(
        /repositories\s*{/,
        `repositories {
        maven {
          url "${ANDROID_SNAPSHOT_REPO_URL}"
          mavenContent {
            snapshotsOnly()
          }
        }`
      );

      // Add the dependencies.
      newConfig.modResults.contents = newConfig.modResults.contents.replace(
        /dependencies\s*{/,
        `dependencies {
        implementation "ai.devrev.sdk:devrev-sdk:${ANDROID_SDK_VERSION}"`
      );
    }
    return newConfig;
  });

  return config;
};

export default withDevRev;
