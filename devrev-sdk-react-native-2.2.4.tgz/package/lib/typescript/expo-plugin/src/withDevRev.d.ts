import { type ConfigPlugin } from '@expo/config-plugins';
export declare const withDevRev: ConfigPlugin;
export default withDevRev;
//# sourceMappingURL=withDevRev.d.ts.map