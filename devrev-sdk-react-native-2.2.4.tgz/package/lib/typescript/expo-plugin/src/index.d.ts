import { withDevRev } from './withDevRev';
export { withDevRev };
export default withDevRev;
//# sourceMappingURL=index.d.ts.map