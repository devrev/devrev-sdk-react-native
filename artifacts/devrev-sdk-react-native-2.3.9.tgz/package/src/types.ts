/**
 * Customization options for the conversation page header branding.
 *
 * @category Configuration
 */
export type ConversationPageOptions = {
  /** Custom text for the conversation header. Uses the server default when omitted. */
  headerText?: string;
  /** Custom text for the conversation subheader. Uses the server default when omitted. Pass a single space (' ') to render a blank subheader. */
  subheaderText?: string;
};

/**
 * Configuration for support widget theme customization.
 *
 * @category Configuration
 */
export type SupportWidgetTheme = {
  /** Whether to prefer the system theme. Defaults to true. */
  prefersSystemTheme: boolean;
  /** Primary text color as a hex string (e.g., '#000000'). Optional. */
  primaryTextColor?: string;
  /** Accent color as a hex string (e.g., '#FF5733'). Optional. */
  accentColor?: string;
  /** Spacing configuration as a map of string keys to string values (e.g., { bottom: '20px', side: '15px' }). Optional. */
  spacing?: { [key: string]: string };
  /** Customizes the conversation page header and subheader text. Optional. */
  conversationPageOptions?: ConversationPageOptions;
};

/**
 * Filter operator for article search filter expressions (DQL-style).
 *
 * @category Configuration
 */
export type FilterOperator =
  | 'all_of'
  | 'and'
  | 'date_time_preset'
  | 'empty'
  | 'eq'
  | 'gt'
  | 'gte'
  | 'in'
  | 'lt'
  | 'lte'
  | 'ne'
  | 'not_empty'
  | 'not_in'
  | 'or';

/**
 * How a filter operand value is interpreted by the API.
 *
 * @category Configuration
 */
export type FilterValueType = 'json' | 'part';

/**
 * A value in a filter operand. Supports all JSON-serializable types.
 *
 * @category Configuration
 */
export type ArticleSearchFilterOperandValue =
  | string
  | number
  | boolean
  | string[]
  | number[]
  | ArticleSearchFilterOperandValue[]
  | { [key: string]: ArticleSearchFilterOperandValue };

/**
 * A single operand in an article search filter expression.
 *
 * @category Configuration
 */
export interface ArticleSearchFilterOperand {
  /** The field to filter on (e.g., 'article.tags.tag_id'). */
  field: string;
  /** The comparison operator for this operand. */
  op: FilterOperator;
  /** The value to compare against. */
  value: ArticleSearchFilterOperandValue;
  /** How the value is encoded for the API. */
  valueType: FilterValueType;
}

/**
 * A filter expression for article search.
 *
 * @category Configuration
 */
export interface ArticleSearchFilter {
  /** The logical operator combining the operands. */
  op: FilterOperator;
  /** The filter conditions. */
  operands: ArticleSearchFilterOperand[];
}

/**
 * Filters for article search in the Widget and/or CMDK surfaces.
 *
 * @category Configuration
 */
export interface ArticleSearchFilters {
  /** Filter applied to PLuG Widget search results. */
  widgetSearch?: ArticleSearchFilter;
  /** Filter applied to CMDK/search bar results. */
  searchBarSearch?: ArticleSearchFilter;
}

/**
 * Feature configuration for the DevRev SDK.
 *
 * @category Configuration
 */
export interface FeatureConfiguration {
  /** Whether to enable frame capture. Defaults to true. */
  enableFrameCapture: boolean;
  /** Whether to automatically start recording. Defaults to true. */
  autoStartRecording: boolean;
  /** Whether to prefer dialog mode (Android only). Defaults to false. */
  prefersDialogMode: boolean;
  /** Whether to always use remote config. Defaults to true. */
  alwaysUseRemoteConfig: boolean;
  /** Support widget theme configuration. */
  supportWidgetTheme: SupportWidgetTheme;
  /** Enables real-time AI agent response streaming in PLuG conversations. Defaults to false. */
  enableSupportChatStreaming?: boolean;
  /** Optional DQL filters for article search in Widget and/or CMDK surfaces. */
  supportWidgetArticleSearchFilters?: ArticleSearchFilters;
}

/* #region Identification types */

/**
 * A JSON-represented structure that describes your customer's identity information.
 * The information can be either on the level of organizations or your user.
 * The minimum information needed is the `userID`.
 *
 * @remarks
 * Some features cannot be used prior to having the user identified.
 *
 * @category Identification
 */
export interface Identity {
  /** A user identifier. */
  userRef: string;
  /** An organization identifier. */
  organizationRef?: string;
  /** An account identifier. */
  accountRef?: string;
  /** A collection of traits describing the user. */
  userTraits?: UserTraits;
  /** A collection of traits describing the organization. */
  organizationTraits?: OrganizationTraits;
  /** A collection of traits describing the account. */
  accountTraits?: AccountTraits;
}

/**
 * A collection of traits describing the user.
 *
 * @category Identification
 */
export interface UserTraits {
  /** The displayed name of the user. */
  displayName?: string;
  /** The user's email. */
  email?: string;
  /** The user's full name. */
  fullName?: string;
  /** The description of the user. */
  description?: string;
  /** The user's phone numbers. */
  phoneNumbers?: string[];
  /**
   * Custom fields for the user.
   *
   * Custom fields need to be configured in the DevRev web app before they can be used.
   * For more information, see: [Object customization](https://devrev.ai/docs/product/object-customization).
   */
  customFields?: { [key: string]: any };
}

/**
 * A collection of traits describing the organization.
 *
 * @category Identification
 */
export interface OrganizationTraits {
  /** The displayed name of the organization. */
  displayName?: string;
  /** The domain of the organization. */
  domain?: string;
  /** The description of the organization. */
  description?: string;
  /** The phone numbers of the organization. */
  phoneNumbers?: string[];
  /** The tier of the organization. */
  tier?: string;
  /**
   * Custom fields for the organization.
   *
   * Custom fields need to be configured in the DevRev web app before they can be used.
   * For more information, see: [Object customization](https://devrev.ai/docs/product/object-customization).
   */
  customFields?: { [key: string]: any };
}

/**
 * A collection of traits describing the account.
 *
 * @category Identification
 */
export interface AccountTraits {
  /** The displayed name of the account. */
  displayName?: string;
  /** The domains of the account. */
  domains?: string[];
  /** The description of the account. */
  description?: string;
  /** The phone numbers of the account. */
  phoneNumbers?: string[];
  /** The websites of the account. */
  websites?: string[];
  /** The tier of the account. */
  tier?: string;
  /**
   * Custom fields for the account.
   *
   * Custom fields need to be configured in the DevRev web app before they can be used.
   * For more information, see: [Object customization](https://devrev.ai/docs/product/object-customization).
   */
  customFields?: { [key: string]: any };
}

/* #endregion */
