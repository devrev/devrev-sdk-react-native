import Foundation
import DevRevSDK

/// Parses bridge dictionaries into ArticleSearchFilters for FeatureConfiguration.
enum ArticleSearchFiltersParser {
	static func parseArticleSearchFilters(from dictionary: [String: Any]) -> ArticleSearchFilters {
		let widgetSearch = (dictionary["widgetSearch"] as? [String: Any])
			.flatMap { parseArticleSearchFilter(from: $0) }
		let searchBarSearch = (dictionary["searchBarSearch"] as? [String: Any])
			.flatMap { parseArticleSearchFilter(from: $0) }
		return ArticleSearchFilters(widgetSearch: widgetSearch, searchBarSearch: searchBarSearch)
	}

	private static func parseArticleSearchFilter(from dictionary: [String: Any]) -> ArticleSearchFilter? {
		guard
			let op = dictionary["op"] as? String,
			let operandsRaw = dictionary["operands"] as? [[String: Any]]
		else {
			return nil
		}
		let operands = operandsRaw.compactMap { parseArticleSearchFilterOperand(from: $0) }
		return ArticleSearchFilter(op: op, operands: operands)
	}

	private static func parseArticleSearchFilterOperand(from dictionary: [String: Any]) -> ArticleSearchFilterOperand? {
		guard
			let field = dictionary["field"] as? String,
			let op = dictionary["op"] as? String,
			let valueTypeString = dictionary["valueType"] as? String,
			let rawValue = dictionary["value"]
		else {
			return nil
		}
		guard let value = ArticleSearchFilterOperandValue(jsonObject: rawValue) else {
			return nil
		}
		return ArticleSearchFilterOperand(
			field: field,
			op: op,
			value: value,
			valueTypeString: valueTypeString
		)
	}
}
