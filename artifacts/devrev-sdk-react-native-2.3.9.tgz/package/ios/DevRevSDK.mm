#import "DevRevSDK/DevRevSDK.h"
#import <React/RCTBridgeModule.h>

#ifdef RCT_NEW_ARCH_ENABLED
#import "DevRevSDKSpec/DevRevSDKSpec.h"
#endif

@interface RCT_EXTERN_MODULE(DevRevSDK, NSObject)

#pragma mark - Configuration

RCT_EXTERN_METHOD(configure:(NSString *) appID version:(NSString *) version featureConfiguration:(NSDictionary * _Nullable) featureConfiguration)
RCT_EXTERN_METHOD(updateFeatureConfiguration:(NSDictionary *) featureConfiguration)

#pragma mark - In-app Link Handling

RCT_EXTERN_METHOD(setShouldDismissModalsOnOpenLink:(BOOL) shouldDismissModalsOnOpenLink)

#pragma mark - Dynamic theme configuration

RCT_EXTERN_METHOD(setPrefersSystemTheme:(BOOL) prefersSystemTheme)

#pragma mark - Identification

RCT_EXTERN_METHOD(
                    identifyUnverifiedUser:(NSString *) userID
                    organizationID:(NSString *) organizationID
)

RCT_EXTERN_METHOD(identifyVerifiedUser:(NSString *) userID sessionToken:(NSString *) sessionToken)

RCT_EXTERN_METHOD(identifyAnonymousUser:(NSString *) userID)

RCT_EXTERN_METHOD(updateUser:(NSDictionary *) identity)

RCT_EXTERN_METHOD(logout:(NSString *) deviceID)

#pragma mark - Support

RCT_EXTERN_METHOD(showSupport)

RCT_EXTERN_METHOD(createSupportConversation:(NSString * _Nullable) prefillMessage)

#pragma mark - Analytics

RCT_EXTERN_METHOD(
                  trackEvent:(NSString *) name
                  properties:(id *) properties
)

#pragma mark - User recording

RCT_EXTERN_METHOD(startRecording)

RCT_EXTERN_METHOD(stopRecording)

RCT_EXTERN_METHOD(pauseRecording)

RCT_EXTERN_METHOD(resumeRecording)

RCT_EXTERN_METHOD(pauseUserInteractionTracking)

RCT_EXTERN_METHOD(resumeUserInteractionTracking)

RCT_EXTERN_METHOD(processAllOnDemandSessions)

#pragma mark - Session properties

RCT_EXTERN_METHOD(addSessionProperties:(id *) properties)

RCT_EXTERN_METHOD(clearSessionProperties)

#pragma mark - Sensitive field masking

RCT_EXTERN_METHOD(markSensitiveViews:(NSArray *) tags)

RCT_EXTERN_METHOD(unmarkSensitiveViews:(NSArray *) tags)

#pragma mark - Timer control

RCT_EXTERN_METHOD(
                  startTimer:(NSString *) name
                  properties:(id *) properties
)

RCT_EXTERN_METHOD(
                  endTimer:(NSString *) name
                  properties:(id *) properties
)

#pragma mark - Monitoring

RCT_EXTERN_METHOD(resumeAllMonitoring)

RCT_EXTERN_METHOD(stopAllMonitoring)

#pragma mark - Screen tracking

RCT_EXTERN_METHOD(
                  trackScreenName:(NSString *) screenName
)

#pragma mark - Push notifications

RCT_EXTERN_METHOD(
                  registerDeviceToken:(NSString *) deviceToken
                  deviceID:(NSString *) deviceID
)

RCT_EXTERN_METHOD(unregisterDevice:(NSString *) deviceID)

RCT_EXTERN_METHOD(processPushNotification:(NSString *) payload)

#pragma mark - Error capture

RCT_EXTERN_METHOD(
                  captureError:(NSString *) error
                  tag:(NSString *) tag
                  stackTrace:(NSString *) stackTrace
)

#pragma mark - Bridge

+ (BOOL)requiresMainQueueSetup
{
    return NO;
}
@end

#ifdef RCT_NEW_ARCH_ENABLED
using namespace facebook;

@implementation DevRevSDK (TurboModule)
- (std::shared_ptr<react::TurboModule>)getTurboModule:(const react::ObjCTurboModule::InitParams &)params {
  return std::make_shared<react::NativeDevRevSDKSpecJSI>(params);
}

@end
#endif
