import Foundation

/// Parses bridge dictionaries into FeatureConfiguration for configure/updateFeatureConfiguration.
enum FeatureConfigurationParser {
	static func parseFeatureConfiguration(from dictionary: [String: Any]) -> FeatureConfiguration {
		let hasEnableFrameCapture = dictionary["enableFrameCapture"] != nil && !(dictionary["enableFrameCapture"] is NSNull)
		let hasAutoStartRecording = dictionary["autoStartRecording"] != nil && !(dictionary["autoStartRecording"] is NSNull)
		let hasAlwaysUseRemoteConfig = dictionary["alwaysUseRemoteConfig"] != nil && !(dictionary["alwaysUseRemoteConfig"] is NSNull)
		let hasSupportWidgetTheme = dictionary["supportWidgetTheme"] != nil && !(dictionary["supportWidgetTheme"] is NSNull)
			&& dictionary["supportWidgetTheme"] is [String: Any]
		let hasEnableSupportChatStreaming = dictionary["enableSupportChatStreaming"] != nil && !(dictionary["enableSupportChatStreaming"] is NSNull)
		let hasSupportWidgetArticleSearchFilters = dictionary["supportWidgetArticleSearchFilters"] != nil
			&& !(dictionary["supportWidgetArticleSearchFilters"] is NSNull)
			&& dictionary["supportWidgetArticleSearchFilters"] is [String: Any]

		// Only supportWidgetTheme passed.
		if !hasEnableFrameCapture, !hasAutoStartRecording, !hasAlwaysUseRemoteConfig,
		   !hasEnableSupportChatStreaming, !hasSupportWidgetArticleSearchFilters,
		   hasSupportWidgetTheme,
		   let themeDict = dictionary["supportWidgetTheme"] as? [String: Any] {
			let theme = SupportWidgetThemeParser.parseSupportWidgetTheme(from: themeDict)
			return FeatureConfiguration(witCustomSupportWidgetTheme: theme)
		}

		// Only enableFrameCapture.
		if hasEnableFrameCapture, !hasAutoStartRecording, !hasAlwaysUseRemoteConfig,
		   !hasSupportWidgetTheme, !hasEnableSupportChatStreaming, !hasSupportWidgetArticleSearchFilters,
		   let value = dictionary["enableFrameCapture"] as? Bool {
			return FeatureConfiguration(withShouldEnableFrameCapture: value)
		}

		let enableFrameCapture = dictionary["enableFrameCapture"] as? Bool ?? true
		let autoStartRecording = dictionary["autoStartRecording"] as? Bool ?? true
		let alwaysUseRemoteConfig = dictionary["alwaysUseRemoteConfig"] as? Bool ?? true
		let enableSupportChatStreaming = dictionary["enableSupportChatStreaming"] as? Bool ?? false
		let supportWidgetTheme: SupportWidgetTheme
		if let themeDict = dictionary["supportWidgetTheme"] as? [String: Any] {
			supportWidgetTheme = SupportWidgetThemeParser.parseSupportWidgetTheme(from: themeDict)
		} else {
			supportWidgetTheme = .systemDefault
		}
		let supportWidgetArticleSearchFilters: ArticleSearchFilters?
		if hasSupportWidgetArticleSearchFilters,
		   let filtersDict = dictionary["supportWidgetArticleSearchFilters"] as? [String: Any] {
			supportWidgetArticleSearchFilters = ArticleSearchFiltersParser.parseArticleSearchFilters(from: filtersDict)
		} else {
			supportWidgetArticleSearchFilters = nil
		}

		return FeatureConfiguration(
			enableFrameCapture: enableFrameCapture,
			autoStartRecording: autoStartRecording,
			alwaysUseRemoteConfig: alwaysUseRemoteConfig,
			supportWidgetTheme: supportWidgetTheme,
			enableSupportChatStreaming: enableSupportChatStreaming,
			supportWidgetArticleSearchFilters: supportWidgetArticleSearchFilters,
			maskAllTextByDefault: false
		)
	}
}

/// Parses supportWidgetTheme dictionary into SupportWidgetTheme.
enum SupportWidgetThemeParser {
	static func parseSupportWidgetTheme(from dictionary: [String: Any]) -> SupportWidgetTheme {
		let prefersSystemTheme = dictionary["prefersSystemTheme"] as? Bool ?? true
		let primaryTextColor = dictionary["primaryTextColor"] as? String
		let accentColor = dictionary["accentColor"] as? String
		let spacing = dictionary["spacing"] as? [String: String]
		let conversationPageOptions: ConversationPageOptions?
		if let optionsDict = dictionary["conversationPageOptions"] as? [String: Any] {
			conversationPageOptions = ConversationPageOptionsParser.parseConversationPageOptions(from: optionsDict)
		} else {
			conversationPageOptions = nil
		}
		return SupportWidgetTheme(
			prefersSystemTheme: prefersSystemTheme,
			primaryTextColor: primaryTextColor,
			accentColor: accentColor,
			spacing: spacing,
			conversationPageOptions: conversationPageOptions
		)
	}
}

/// Parses conversationPageOptions dictionary into ConversationPageOptions.
enum ConversationPageOptionsParser {
	static func parseConversationPageOptions(from dictionary: [String: Any]) -> ConversationPageOptions {
		let headerText = dictionary["headerText"] as? String
		let subheaderText = dictionary["subheaderText"] as? String
		return ConversationPageOptions(
			headerText: headerText,
			subheaderText: subheaderText
		)
	}
}

