import type { TurboModule } from 'react-native';
interface ConversationPageOptions {
    headerText?: string;
    subheaderText?: string;
}
interface SupportWidgetTheme {
    prefersSystemTheme: boolean;
    primaryTextColor?: string;
    accentColor?: string;
    spacing?: {
        [key: string]: string;
    };
    conversationPageOptions?: ConversationPageOptions;
}
interface ArticleSearchFilterOperand {
    field: string;
    op: string;
    value: Object;
    valueType: string;
}
interface ArticleSearchFilter {
    op: string;
    operands: ReadonlyArray<ArticleSearchFilterOperand>;
}
interface ArticleSearchFilters {
    widgetSearch?: ArticleSearchFilter;
    searchBarSearch?: ArticleSearchFilter;
}
interface FeatureConfiguration {
    enableFrameCapture: boolean;
    autoStartRecording: boolean;
    prefersDialogMode: boolean;
    alwaysUseRemoteConfig: boolean;
    supportWidgetTheme: SupportWidgetTheme;
    enableSupportChatStreaming?: boolean;
    supportWidgetArticleSearchFilters?: ArticleSearchFilters;
}
export interface Spec extends TurboModule {
    configure(appId: string, version: string, featureConfiguration?: FeatureConfiguration): void;
    updateFeatureConfiguration(featureConfiguration: FeatureConfiguration): void;
    identifyUnverifiedUser(userId: string, organizationId?: string): void;
    identifyVerifiedUser(userId: string, sessionToken: string): void;
    identifyAnonymousUser(userId: string): void;
    updateUser(identity: Object): void;
    logout(deviceId: string): void;
    showSupport(): void;
    createSupportConversation(prefillMessage?: string): void;
    trackEvent(name: string, properties?: Object): void;
    startRecording(): void;
    stopRecording(): void;
    pauseRecording(): void;
    resumeRecording(): void;
    pauseUserInteractionTracking(): void;
    resumeUserInteractionTracking(): void;
    processAllOnDemandSessions(): void;
    addSessionProperties(properties: Object): void;
    clearSessionProperties(): void;
    markSensitiveViews(views: ReadonlyArray<Object>): void;
    unmarkSensitiveViews(views: ReadonlyArray<Object>): void;
    startTimer(name: string, properties?: Object): void;
    endTimer(name: string, properties?: Object): void;
    resumeAllMonitoring(): void;
    stopAllMonitoring(): void;
    trackScreenName(name: string): void;
    registerDeviceToken(deviceToken: string, deviceId: string): void;
    unregisterDevice(deviceId: string): void;
    processPushNotification(payload: string): void;
    setInAppLinkHandler(): void;
    setShouldDismissModalsOnOpenLink(value: boolean): void;
    setPrefersSystemTheme(value: boolean): void;
    setInScreenTransitioning(value: boolean): void;
    getConstants(): {
        EVENT_IN_APP_LINK: string;
    };
    addListener(eventName: string): void;
    removeListeners(count: number): void;
    captureError(error: string, tag: string, stackTrace?: string): void;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeDevRevSDK.d.ts.map