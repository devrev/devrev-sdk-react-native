package ai.devrev.sdk.bridge.reactnative

import ai.devrev.sdk.model.ConversationPageOptions
import ai.devrev.sdk.model.FeatureConfiguration
import ai.devrev.sdk.model.SupportWidgetTheme
import com.facebook.react.bridge.ReadableMap

object FeatureConfigurationParser {
    fun parseFeatureConfiguration(map: ReadableMap?): FeatureConfiguration {
        if (map == null) return FeatureConfiguration.default

        val enableFrameCapture = map.getBooleanOrDefault("enableFrameCapture", true)
        val autoStartRecording = map.getBooleanOrDefault("autoStartRecording", true)
        val prefersDialogMode = map.getBooleanOrDefault("prefersDialogMode", false)
        val alwaysUseRemoteConfig = map.getBooleanOrDefault("alwaysUseRemoteConfig", true)
        val enableSupportChatStreaming = map.getBooleanOrDefault("enableSupportChatStreaming", false)
        val supportWidgetTheme = map
            .getMapOrNull("supportWidgetTheme")
            ?.let { themeMap -> SupportWidgetThemeParser.parseSupportWidgetTheme(themeMap) }
        val supportWidgetArticleSearchFilters = map
            .getMapOrNull("supportWidgetArticleSearchFilters")
            ?.let { filtersMap -> ArticleSearchFiltersParser.parseArticleSearchFilters(filtersMap) }

        return if (supportWidgetTheme != null) {
            FeatureConfiguration(
                enableFrameCapture = enableFrameCapture,
                autoStartRecording = autoStartRecording,
                prefersDialogMode = prefersDialogMode,
                alwaysUseRemoteConfig = alwaysUseRemoteConfig,
                supportWidgetTheme = supportWidgetTheme,
                enableSupportChatStreaming = enableSupportChatStreaming,
                supportWidgetArticleSearchFilters = supportWidgetArticleSearchFilters
            )
        } else {
            FeatureConfiguration(
                enableFrameCapture = enableFrameCapture,
                autoStartRecording = autoStartRecording,
                prefersDialogMode = prefersDialogMode,
                alwaysUseRemoteConfig = alwaysUseRemoteConfig,
                enableSupportChatStreaming = enableSupportChatStreaming,
                supportWidgetArticleSearchFilters = supportWidgetArticleSearchFilters
            )
        }
    }
}

object SupportWidgetThemeParser {
    fun parseSupportWidgetTheme(map: ReadableMap?): SupportWidgetTheme? {
        if (map == null) return null

        return SupportWidgetTheme(
            prefersSystemTheme = map.getBooleanOrDefault("prefersSystemTheme", true),
            primaryTextColor = map.getStringOrNull("primaryTextColor"),
            accentColor = map.getStringOrNull("accentColor"),
            spacing = map.getMapOrNull("spacing")?.toSpacingMap(),
            conversationPageOptions = map
                .getMapOrNull("conversationPageOptions")
                ?.let { optionsMap -> ConversationPageOptionsParser.parseConversationPageOptions(optionsMap) }
        )
    }
}

object ConversationPageOptionsParser {
    fun parseConversationPageOptions(map: ReadableMap): ConversationPageOptions {
        return ConversationPageOptions(
            headerText = map.getStringOrNull("headerText"),
            subheaderText = map.getStringOrNull("subheaderText")
        )
    }
}
