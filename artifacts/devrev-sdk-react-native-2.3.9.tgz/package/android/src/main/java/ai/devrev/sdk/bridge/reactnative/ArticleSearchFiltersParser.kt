package ai.devrev.sdk.bridge.reactnative

import ai.devrev.sdk.model.ArticleSearchFilter
import ai.devrev.sdk.model.ArticleSearchFilterOperand
import ai.devrev.sdk.model.ArticleSearchFilters
import ai.devrev.sdk.model.FilterOperator
import ai.devrev.sdk.model.FilterValueType
import com.facebook.react.bridge.ReadableArray
import com.facebook.react.bridge.ReadableMap

object ArticleSearchFiltersParser {

    fun parseArticleSearchFilters(map: ReadableMap): ArticleSearchFilters {
        val widgetSearch = map.getMapOrNull("widgetSearch")
            ?.let { filterMap -> parseArticleSearchFilter(filterMap) }
        val searchBarSearch = map.getMapOrNull("searchBarSearch")
            ?.let { filterMap -> parseArticleSearchFilter(filterMap) }
        return ArticleSearchFilters(
            widgetSearch = widgetSearch,
            searchBarSearch = searchBarSearch
        )
    }

    private fun parseArticleSearchFilter(map: ReadableMap): ArticleSearchFilter? {
        val opString = map.getStringOrNull("op") ?: return null
        val op = parseFilterOperator(opString) ?: return null
        val operandsArray = map.getArrayOrNull("operands") ?: return null
        val operands = parseOperands(operandsArray)
        return ArticleSearchFilter(op = op, operands = operands)
    }

    private fun parseOperands(array: ReadableArray): List<ArticleSearchFilterOperand> {
        val result = mutableListOf<ArticleSearchFilterOperand>()
        for (i in 0 until array.size()) {
            val operandMap = array.getMap(i) ?: continue
            parseOperand(operandMap)?.let { operand -> result.add(operand) }
        }
        return result
    }

    private fun parseOperand(map: ReadableMap): ArticleSearchFilterOperand? {
        val field = map.getStringOrNull("field") ?: return null
        val opString = map.getStringOrNull("op") ?: return null
        val op = parseFilterOperator(opString) ?: return null
        val value = parseValue(map) ?: return null
        val valueTypeString = map.getStringOrNull("valueType") ?: return null
        val valueType = parseFilterValueType(valueTypeString) ?: return null
        return ArticleSearchFilterOperand(
            field = field,
            op = op,
            value = value,
            valueType = valueType
        )
    }

    private fun parseValue(map: ReadableMap): List<String>? {
        val valueArray = map.getArrayOrNull("value") ?: return null
        return parseStringArray(valueArray)
    }

    private fun parseStringArray(array: ReadableArray): List<String> {
        val result = mutableListOf<String>()
        for (i in 0 until array.size()) {
            array.getString(i)?.let { str -> result.add(str) }
        }
        return result
    }

    private fun parseFilterOperator(value: String): FilterOperator? {
        return when (value) {
            "all_of" -> FilterOperator.ALL_OF
            "and" -> FilterOperator.AND
            "date_time_preset" -> FilterOperator.DATE_TIME_PRESET
            "empty" -> FilterOperator.EMPTY
            "eq" -> FilterOperator.EQ
            "gt" -> FilterOperator.GT
            "gte" -> FilterOperator.GTE
            "in" -> FilterOperator.IN
            "lt" -> FilterOperator.LT
            "lte" -> FilterOperator.LTE
            "ne" -> FilterOperator.NE
            "not_empty" -> FilterOperator.NOT_EMPTY
            "not_in" -> FilterOperator.NOT_IN
            "or" -> FilterOperator.OR
            else -> null
        }
    }

    private fun parseFilterValueType(value: String): FilterValueType? {
        return when (value) {
            "json" -> FilterValueType.JSON
            "part" -> FilterValueType.PART
            else -> null
        }
    }
}
