package ai.devrev.sdk.bridge.reactnative

import com.facebook.react.bridge.ReadableArray
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.bridge.ReadableType

internal fun ReadableMap.getBooleanOrDefault(key: String, default: Boolean): Boolean {
    return if (hasKey(key) && !isNull(key) && getType(key) == ReadableType.Boolean) getBoolean(key) else default
}

internal fun ReadableMap.getStringOrNull(key: String): String? {
    return if (hasKey(key) && !isNull(key) && getType(key) == ReadableType.String) getString(key) else null
}

internal fun ReadableMap.getMapOrNull(key: String): ReadableMap? {
    return if (hasKey(key) && !isNull(key) && getType(key) == ReadableType.Map) getMap(key) else null
}

internal fun ReadableMap.getArrayOrNull(key: String): ReadableArray? {
    return if (hasKey(key) && !isNull(key) && getType(key) == ReadableType.Array) getArray(key) else null
}

internal fun ReadableMap.toSpacingMap(): Map<String, String>? {
    val result = mutableMapOf<String, String>()
    val iterator = keySetIterator()
    while (iterator.hasNextKey()) {
        val key = iterator.nextKey()
        getString(key)?.let { value -> result[key] = value }
    }
    return result.takeIf { it.isNotEmpty() }
}
