package ai.devrev.sdk.bridge.reactnative

import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.ReadableArray
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.module.annotations.ReactModule
import android.view.View
import com.facebook.react.uimanager.UIManagerHelper
import com.facebook.react.bridge.ReactContext
import com.facebook.react.bridge.UiThreadUtil
import android.util.Log

@ReactModule(name = DevRevSDKModule.NAME)
class DevRevSDKModule(reactContext: ReactApplicationContext) :
    NativeDevRevSDKSpec(reactContext) {

    private val devrevSDK: IDevRevSDKModule = DevRevSDKModuleImpl(reactContext)

    companion object {
        const val NAME = "DevRevSDK"
    }

    override fun getName(): String = NAME

    /*
     * Configuration
     */

    @ReactMethod
    override fun configure(appId: String, version: String, featureConfiguration: ReadableMap?) {
        devrevSDK.configure(appId, version, featureConfiguration)
    }

    @ReactMethod
    override fun updateFeatureConfiguration(featureConfiguration: ReadableMap) {
        devrevSDK.updateFeatureConfiguration(featureConfiguration)
    }

    /*
     * Identification
     */

    @ReactMethod
    override fun identifyUnverifiedUser(userId: String, organizationId: String?) {
        devrevSDK.identifyUnverifiedUser(userId, organizationId)
    }

    @ReactMethod
    override fun identifyVerifiedUser(userId: String, sessionToken: String) {
        devrevSDK.identifyVerifiedUser(userId, sessionToken)
    }

    @ReactMethod
    override fun identifyAnonymousUser(userId: String) {
        devrevSDK.identifyAnonymousUser(userId)
    }

    @ReactMethod
    override fun updateUser(identity: ReadableMap) {
        devrevSDK.updateUser(identity)
    }

    @ReactMethod
    override fun logout(deviceId: String) {
        devrevSDK.logout(deviceId)
    }

    /*
     * Support
     */

    @ReactMethod
    override fun showSupport() {
        devrevSDK.showSupport()
    }

    @ReactMethod
    override fun createSupportConversation(prefillMessage: String?) {
        devrevSDK.createSupportConversation(prefillMessage)
    }

    /*
     * Analytics
     */

    @ReactMethod
    override fun trackEvent(name: String, properties: ReadableMap?) {
        devrevSDK.trackEvent(name, properties)
    }

    /*
     * Session recording
     */

    @ReactMethod
    override fun startRecording() {
        devrevSDK.startRecording()
    }

    @ReactMethod
    override fun stopRecording() {
        devrevSDK.stopRecording()
    }

    @ReactMethod
    override fun pauseRecording() {
        devrevSDK.pauseRecording()
    }

    @ReactMethod
    override fun resumeRecording() {
        devrevSDK.resumeRecording()
    }

    @ReactMethod
    override fun pauseUserInteractionTracking() {
        devrevSDK.pauseUserInteractionTracking()
    }

    @ReactMethod
    override fun resumeUserInteractionTracking() {
        devrevSDK.resumeUserInteractionTracking()
    }

    @ReactMethod
    override fun processAllOnDemandSessions() {
        devrevSDK.processAllOnDemandSessions()
    }

    /*
     * Session properties
     */

    @ReactMethod
    override fun addSessionProperties(properties: ReadableMap?) {
        devrevSDK.addSessionProperties(properties)
    }

    @ReactMethod
    override fun clearSessionProperties() {
        devrevSDK.clearSessionProperties()
    }

    /*
     * Sensitive field masking
     */

    @ReactMethod
    override fun markSensitiveViews(views: ReadableArray) {
        UiThreadUtil.runOnUiThread {
          val context = super.getReactApplicationContext()
          val views = convertReactTagsToViews(context, views)
          Log.d("DEVREV SDK", "Mark sensitive views resolved views: ${views.size}")
          if (views.isNotEmpty()) {
              devrevSDK.markSensitiveViews(views)
          }
        }
    }

    @ReactMethod
    override fun unmarkSensitiveViews(views: ReadableArray) {
        UiThreadUtil.runOnUiThread {
          val context = super.getReactApplicationContext()
          val views = convertReactTagsToViews(context, views)
          Log.d("DEVREV SDK", "Unmark sensitive views resolved views: ${views.size}")
          if (views.isNotEmpty()) {
              devrevSDK.unmarkSensitiveViews(views)
          }
        }
    }

    /*
     * Timer control
     */

    @ReactMethod
    override fun startTimer(name: String, properties: ReadableMap?) {
        devrevSDK.startTimer(name, properties)
    }

    @ReactMethod
    override fun endTimer(name: String, properties: ReadableMap?) {
        devrevSDK.endTimer(name, properties)
    }

    /*
     * Session monitoring
     */

    @ReactMethod
    override fun resumeAllMonitoring() {
        devrevSDK.resumeAllMonitoring()
    }

    @ReactMethod
    override fun stopAllMonitoring() {
        devrevSDK.stopAllMonitoring()
    }

    /*
     * Screen tracking
     */

    @ReactMethod
    override fun trackScreenName(name: String) {
        devrevSDK.trackScreenName(name)
    }

    /*
     * Push notifications
     */

    @ReactMethod
    override fun registerDeviceToken(deviceToken: String, deviceId: String) {
        devrevSDK.registerDeviceToken(deviceToken, deviceId)
    }

    @ReactMethod
    override fun unregisterDevice(deviceId: String) {
        devrevSDK.unregisterDevice(deviceId)
    }

    @ReactMethod
    override fun processPushNotification(payload: String) {
        devrevSDK.processPushNotification(payload)
    }

    /*
     * In-app link handling
     */

    @ReactMethod
    override fun setInAppLinkHandler() {
        devrevSDK.setInAppLinkHandler()
    }

    @ReactMethod
    override fun setShouldDismissModalsOnOpenLink(value: Boolean) {
        devrevSDK.setShouldDismissModalsOnOpenLink(value)
    }

    /*
     * Dynamic theme configuration
     */

    @ReactMethod
    override fun setPrefersSystemTheme(value: Boolean) {
        devrevSDK.setPrefersSystemTheme(value)
    }

    /*
     * Screen transition management
     */

    @ReactMethod
    override fun setInScreenTransitioning(value: Boolean) {
        devrevSDK.setInScreenTransitioning(value)
    }

    /*
     * Event listener management
     */

    @ReactMethod
    override fun addListener(eventName: String) {
        devrevSDK.addListener(eventName)
    }

    @ReactMethod
    override fun removeListeners(count: Double) {
        // Convert Double to Int for devrevSDK
        devrevSDK.removeListeners(count.toInt())
    }

    /*
     * Error capture
     */

    @ReactMethod
    override fun captureError(error: String, tag: String, stackTrace: String?) {
        devrevSDK.captureError(error, tag, stackTrace)
    }

    /*
     * Constants
     */

    override fun getTypedExportedConstants(): Map<String, Any> = devrevSDK.getDevRevConstants()
}
