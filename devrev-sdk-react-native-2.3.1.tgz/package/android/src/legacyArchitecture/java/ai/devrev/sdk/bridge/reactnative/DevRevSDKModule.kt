package ai.devrev.sdk.bridge.reactnative

import ai.devrev.sdk.DevRev
import ai.devrev.sdk.addSessionProperties
import ai.devrev.sdk.clearSessionProperties
import ai.devrev.sdk.endTimer
import ai.devrev.sdk.markSensitiveViews
import ai.devrev.sdk.model.Identity
import ai.devrev.sdk.pauseRecording
import ai.devrev.sdk.resumeAllMonitoring
import ai.devrev.sdk.resumeRecording
import ai.devrev.sdk.showSupport
import ai.devrev.sdk.startRecording
import ai.devrev.sdk.startTimer
import ai.devrev.sdk.stopAllMonitoring
import ai.devrev.sdk.stopRecording
import ai.devrev.sdk.trackEvent
import ai.devrev.sdk.trackScreenName
import ai.devrev.sdk.unmarkSensitiveViews
import ai.devrev.sdk.setInScreenTransitioning
import ai.devrev.sdk.processAllOnDemandSessions
import android.app.Activity
import android.util.Log
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.bridge.ReadableArray
import com.facebook.react.bridge.ReadableMapKeySetIterator
import com.facebook.react.bridge.ReadableType
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.facebook.react.uimanager.NativeViewHierarchyManager;
import com.facebook.react.uimanager.UIBlock;
import com.facebook.react.uimanager.UIManagerModule;
import com.facebook.react.uimanager.ViewManager;
import android.view.View;
import com.facebook.react.bridge.UiThreadUtil
import com.facebook.react.uimanager.UIManagerHelper

class DevRevSDKModule(reactContext: ReactApplicationContext) :
  ReactContextBaseJavaModule(reactContext) {

  private val devrevSDK = DevRevSDKModuleFactory.create(reactContext)

  override fun getName(): String {
    return NAME
  }

  companion object {
    const val NAME = "DevRevSDK"
  }

  /*
   * Configuration
   */

  @ReactMethod
  fun configure(appId: String, version: String, featureConfiguration: ReadableMap?) {
    devrevSDK.configure(appId, version, featureConfiguration)
  }

  @ReactMethod
  fun updateFeatureConfiguration(featureConfiguration: ReadableMap) {
    devrevSDK.updateFeatureConfiguration(featureConfiguration)
  }

  /*
   * Identification
   */

  @ReactMethod
  fun identifyUnverifiedUser(userId: String, organizationId: String?) {
    devrevSDK.identifyUnverifiedUser(userId, organizationId)
  }

  @ReactMethod
  fun identifyVerifiedUser(userId: String, sessionToken: String) {
    devrevSDK.identifyVerifiedUser(userId, sessionToken)
  }

  @ReactMethod
  fun identifyAnonymousUser(userId: String) {
    devrevSDK.identifyAnonymousUser(userId)
  }

  @ReactMethod
  fun updateUser(identity: ReadableMap) {
    devrevSDK.updateUser(identity)
  }

  @ReactMethod
  fun logout(deviceId: String) {
    devrevSDK.logout(deviceId)
  }

  /*
   * Support
   */

  @ReactMethod
  fun showSupport() {
    devrevSDK.showSupport()
  }

  @ReactMethod
  fun createSupportConversation() {
    devrevSDK.createSupportConversation()
  }

  /*
   * Analytics
   */

  @ReactMethod
  fun trackEvent(name: String, properties: ReadableMap?) {
    devrevSDK.trackEvent(name, properties)
  }

  /*
   * Session recording
   */

  @ReactMethod
  fun startRecording() {
    devrevSDK.startRecording()
  }

  @ReactMethod
  fun stopRecording() {
    devrevSDK.stopRecording()
  }

  @ReactMethod
  fun pauseRecording() {
    devrevSDK.pauseRecording()
  }

  @ReactMethod
  fun resumeRecording() {
    devrevSDK.resumeRecording()
  }

  @ReactMethod
  fun pauseUserInteractionTracking() {
    devrevSDK.pauseUserInteractionTracking()
  }

  @ReactMethod
  fun resumeUserInteractionTracking() {
    devrevSDK.resumeUserInteractionTracking()
  }

  @ReactMethod
  fun processAllOnDemandSessions() {
    devrevSDK.processAllOnDemandSessions()
  }

  /*
   * Session properties
   */

  @ReactMethod
  fun addSessionProperties(properties: ReadableMap?) {
    devrevSDK.addSessionProperties(properties)
  }

  @ReactMethod
  fun clearSessionProperties() {
    devrevSDK.clearSessionProperties()
  }

  /*
   * Sensitive field masking
   */

  @ReactMethod
  fun markSensitiveViews(viewTags: ReadableArray) {
      UiThreadUtil.runOnUiThread {
        val context = super.getReactApplicationContext()
        val views = convertReactTagsToViews(context, viewTags)
        Log.d("DEVREV SDK", "Mark sensitive views resolved views: ${views.size}")
        if (views.isNotEmpty()) {
          devrevSDK.markSensitiveViews(views)
        }
      }
  }

  @ReactMethod
  fun unmarkSensitiveViews(viewTags: ReadableArray) {
      UiThreadUtil.runOnUiThread {
        val context = super.getReactApplicationContext()
        val views = convertReactTagsToViews(context, viewTags)
        Log.d("DEVREV SDK", "Unmark sensitive views resolved views: ${views.size}")
        if (views.isNotEmpty()) {
          devrevSDK.unmarkSensitiveViews(views)
        }
      }
  }

  /*
   * Timer control
   */

  @ReactMethod
  fun startTimer(name: String, properties: ReadableMap?) {
    devrevSDK.startTimer(name, properties)
  }

  @ReactMethod
  fun endTimer(name: String, properties: ReadableMap?) {
    devrevSDK.endTimer(name, properties)
  }

  /*
   * Monitoring
   */

  @ReactMethod
  fun resumeAllMonitoring() {
    devrevSDK.resumeAllMonitoring()
  }

  @ReactMethod
  fun stopAllMonitoring() {
    devrevSDK.stopAllMonitoring()
  }

  /*
   * Screen tracking
   */

  @ReactMethod
  fun trackScreenName(name: String) {
    devrevSDK.trackScreenName(name)
  }

  /*
   * Push notifications
   */

  @ReactMethod
  fun registerDeviceToken(deviceToken: String, deviceId: String) {
    val context = super.getReactApplicationContext()
    devrevSDK.registerDeviceToken(deviceToken, deviceId)
  }

  @ReactMethod
  fun unregisterDevice(deviceId: String) {
    val context = super.getReactApplicationContext()
    devrevSDK.unregisterDevice(deviceId)
  }

  @ReactMethod
  fun processPushNotification(payload: String) {
    val context = super.getReactApplicationContext()
    devrevSDK.processPushNotification(payload)
  }

  /*
   * In-app link handling
   */

  @ReactMethod
  fun setInAppLinkHandler() {
    devrevSDK.setInAppLinkHandler()
  }

  @ReactMethod
  fun setShouldDismissModalsOnOpenLink(value: Boolean) {
    devrevSDK.setShouldDismissModalsOnOpenLink(value)
  }

  /*
   * Dynamic theme configuration
   */

  @ReactMethod
  fun setPrefersSystemTheme(value: Boolean) {
    devrevSDK.setPrefersSystemTheme(value)
  }

  /*
   * Screen transition management
   */

  @ReactMethod
  fun setInScreenTransitioning(value: Boolean) {
    devrevSDK.setInScreenTransitioning(value)
  }

  /*
   * Event listener management
   */

  @ReactMethod
  fun addListener(eventName: String) {
  }

  @ReactMethod
  fun removeListeners(count: Int) {
  }

  /*
   * Error capture
   */

  @ReactMethod
  fun captureError(error: String, tag: String, stackTrace: String?) {
    devrevSDK.captureError(error, tag, stackTrace)
  }

  override fun getConstants(): Map<String, Any> = devrevSDK.getDevRevConstants()
}
