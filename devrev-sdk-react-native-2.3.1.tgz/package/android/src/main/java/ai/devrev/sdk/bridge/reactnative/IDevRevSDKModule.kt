package ai.devrev.sdk.bridge.reactnative

import com.facebook.react.bridge.ReadableMap

interface IDevRevSDKModule {
    /*
     * Configuration
     */

    fun configure(appId: String, version: String, featureConfiguration: ReadableMap?)
    fun updateFeatureConfiguration(featureConfiguration: ReadableMap)

    /*
     * Identification
     */

    fun identifyUnverifiedUser(userId: String, organizationId: String?)
    fun identifyVerifiedUser(userId: String, sessionToken: String)
    fun identifyAnonymousUser(userId: String)
    fun updateUser(identity: ReadableMap)
    fun logout(deviceId: String)

    /*
     * Support
     */

    fun showSupport()
    fun createSupportConversation()

    /*
     * Analytics
     */

    fun trackEvent(name: String, properties: ReadableMap?)

    /*
     * Session recording
     */

    fun startRecording()
    fun stopRecording()
    fun pauseRecording()
    fun resumeRecording()
    fun pauseUserInteractionTracking()
    fun resumeUserInteractionTracking()
    fun processAllOnDemandSessions()

    /*
     * Session properties
     */

    fun addSessionProperties(properties: ReadableMap?)
    fun clearSessionProperties()

    /*
     * Sensitive field masking
     */

    fun markSensitiveViews(views: List<android.view.View>)
    fun unmarkSensitiveViews(views: List<android.view.View>)

    /*
     * Timer control
     */

    fun startTimer(name: String, properties: ReadableMap?)
    fun endTimer(name: String, properties: ReadableMap?)

    /*
     * Monitoring
     */

    fun resumeAllMonitoring()
    fun stopAllMonitoring()

    /*
     * Screen tracking
     */

    fun trackScreenName(name: String)

    /*
     * Push notifications
     */

    fun registerDeviceToken(deviceToken: String, deviceId: String)
    fun unregisterDevice(deviceId: String)
    fun processPushNotification(payload: String)

    /*
     * In-app link handling
     */

    fun setInAppLinkHandler()
    fun setShouldDismissModalsOnOpenLink(value: Boolean)

    /*
     * Dynamic theme configuration
     */

    fun setPrefersSystemTheme(value: Boolean)

    /*
     * Screen transition management
     */

    fun setInScreenTransitioning(value: Boolean)

    /*
     * Constants
     */

    fun getDevRevConstants(): Map<String, Any>

    /*
     * Event Listener Management
     */

    fun addListener(eventName: String)
    fun removeListeners(count: Int)

    /*
     * Error capture
     */

    fun captureError(error: String, tag: String, stackTrace: String?)
}
