package ai.devrev.sdk.bridge.reactnative

import ai.devrev.sdk.model.FeatureConfiguration
import ai.devrev.sdk.model.SupportWidgetTheme
import com.facebook.react.bridge.ReadableMap

object FeatureConfigurationParser {
    fun parseFeatureConfiguration(map: ReadableMap?): FeatureConfiguration {
        if (map == null) return FeatureConfiguration.default

        val enableFrameCapture = map.getBooleanOrDefault("enableFrameCapture", true)
        val autoStartRecording = map.getBooleanOrDefault("autoStartRecording", true)
        val prefersDialogMode = map.getBooleanOrDefault("prefersDialogMode", false)
        val alwaysUseRemoteConfig = map.getBooleanOrDefault("alwaysUseRemoteConfig", true)
        val supportWidgetTheme = map
            .getMapOrNull("supportWidgetTheme")
            ?.let { SupportWidgetThemeParser.parseSupportWidgetTheme(it) }

        return if (supportWidgetTheme != null) {
            FeatureConfiguration(
                enableFrameCapture = enableFrameCapture,
                autoStartRecording = autoStartRecording,
                prefersDialogMode = prefersDialogMode,
                alwaysUseRemoteConfig = alwaysUseRemoteConfig,
                supportWidgetTheme = supportWidgetTheme
            )
        } else {
            FeatureConfiguration(
                enableFrameCapture = enableFrameCapture,
                autoStartRecording = autoStartRecording,
                prefersDialogMode = prefersDialogMode,
                alwaysUseRemoteConfig = alwaysUseRemoteConfig
            )
        }
    }
}

object SupportWidgetThemeParser {
    fun parseSupportWidgetTheme(map: ReadableMap?): SupportWidgetTheme? {
        if (map == null) return null

        return SupportWidgetTheme(
            prefersSystemTheme = map.getBooleanOrDefault("prefersSystemTheme", true),
            primaryTextColor = map.getStringOrNull("primaryTextColor"),
            accentColor = map.getStringOrNull("accentColor"),
            spacing = map.getMapOrNull("spacing")?.toSpacingMap()
        )
    }
}

private fun ReadableMap.getBooleanOrDefault(key: String, default: Boolean): Boolean {
    return if (hasKey(key) && !isNull(key)) getBoolean(key) else default
}

private fun ReadableMap.getStringOrNull(key: String): String? {
    return if (hasKey(key) && !isNull(key)) getString(key) else null
}

private fun ReadableMap.getMapOrNull(key: String): ReadableMap? {
    return if (hasKey(key) && !isNull(key)) getMap(key) else null
}

private fun ReadableMap.toSpacingMap(): Map<String, String>? {
    val result = mutableMapOf<String, String>()
    val iterator = keySetIterator()
    while (iterator.hasNextKey()) {
        val key = iterator.nextKey()
        getString(key)?.let { result[key] = it }
    }
    return result.takeIf { it.isNotEmpty() }
}
