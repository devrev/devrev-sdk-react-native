import Foundation

/// Parses bridge dictionaries into FeatureConfiguration for configure/updateFeatureConfiguration.
enum FeatureConfigurationParser {
	static func parseFeatureConfiguration(from dictionary: [String: Any]) -> FeatureConfiguration {
		let hasEnableFrameCapture = dictionary["enableFrameCapture"] != nil && !(dictionary["enableFrameCapture"] is NSNull)
		let hasAutoStartRecording = dictionary["autoStartRecording"] != nil && !(dictionary["autoStartRecording"] is NSNull)
		let hasAlwaysUseRemoteConfig = dictionary["alwaysUseRemoteConfig"] != nil && !(dictionary["alwaysUseRemoteConfig"] is NSNull)
		let hasSupportWidgetTheme = dictionary["supportWidgetTheme"] != nil && !(dictionary["supportWidgetTheme"] is NSNull)
			&& dictionary["supportWidgetTheme"] is [String: Any]

		// Only supportWidgetTheme passed .
		if !hasEnableFrameCapture, !hasAutoStartRecording, !hasAlwaysUseRemoteConfig, hasSupportWidgetTheme,
		   let themeDict = dictionary["supportWidgetTheme"] as? [String: Any] {
			let theme = SupportWidgetThemeParser.parseSupportWidgetTheme(from: themeDict)
			return FeatureConfiguration(witCustomSupportWidgetTheme: theme)
		}

		// Only enableFrameCapture.
		if hasEnableFrameCapture, !hasAutoStartRecording, !hasAlwaysUseRemoteConfig, !hasSupportWidgetTheme,
		   let value = dictionary["enableFrameCapture"] as? Bool {
			return FeatureConfiguration(withShouldEnableFrameCapture: value)
		}

		let enableFrameCapture = dictionary["enableFrameCapture"] as? Bool ?? true
		let autoStartRecording = dictionary["autoStartRecording"] as? Bool ?? true
		let alwaysUseRemoteConfig = dictionary["alwaysUseRemoteConfig"] as? Bool ?? true
		let supportWidgetTheme: SupportWidgetTheme
		if let themeDict = dictionary["supportWidgetTheme"] as? [String: Any] {
			supportWidgetTheme = SupportWidgetThemeParser.parseSupportWidgetTheme(from: themeDict)
		} else {
			supportWidgetTheme = .systemDefault
		}

		return FeatureConfiguration(
			enableFrameCapture: enableFrameCapture,
			autoStartRecording: autoStartRecording,
			alwaysUseRemoteConfig: alwaysUseRemoteConfig,
			supportWidgetTheme: supportWidgetTheme
		)
	}
}

/// Parses supportWidgetTheme dictionary into SupportWidgetTheme.
enum SupportWidgetThemeParser {
	static func parseSupportWidgetTheme(from dictionary: [String: Any]) -> SupportWidgetTheme {
		let prefersSystemTheme = dictionary["prefersSystemTheme"] as? Bool ?? true
		let primaryTextColor = dictionary["primaryTextColor"] as? String
		let accentColor = dictionary["accentColor"] as? String
		let spacing = dictionary["spacing"] as? [String: String]
		return SupportWidgetTheme(
			prefersSystemTheme: prefersSystemTheme,
			primaryTextColor: primaryTextColor,
			accentColor: accentColor,
			spacing: spacing
		)
	}
}
